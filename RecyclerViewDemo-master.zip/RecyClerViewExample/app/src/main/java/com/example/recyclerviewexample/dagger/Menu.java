package com.example.recyclerviewexample.dagger;

import java.util.Map;

public class Menu {

    Map<String, Boolean> menus;

    public Menu(Map<String, Boolean> menus) {
        this.menus = menus;
    }

    public Map<String, Boolean> getMenus() {
        return menus;
    }

}
