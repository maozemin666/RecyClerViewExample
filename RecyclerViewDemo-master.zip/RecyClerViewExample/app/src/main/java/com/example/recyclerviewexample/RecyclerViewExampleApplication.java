package com.example.recyclerviewexample;

import android.app.Application;

import com.example.recyclerviewexample.dagger.Chef;

import dagger.android.AndroidInjector;
import dagger.android.DaggerApplication;

public class RecyclerViewExampleApplication extends Application {



}
