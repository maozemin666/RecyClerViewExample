package com.example.recyclerviewexample.dagger;

import com.example.recyclerviewexample.activity.DaggerActivity;

import dagger.Module;
import dagger.android.ContributesAndroidInjector;

@Module
public abstract class ActivityModules {

    @ContributesAndroidInjector
    abstract DaggerActivity contributeDaggerActivity();
}
