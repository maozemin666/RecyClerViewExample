package com.example.recyclerviewexample.utils;

public class AppConstant {
    private AppConstant() {
    }

    public static final String LINE_SEPARATOR = "\n";
    public static final String LINE_SEPARATOR2 = "\n\n";
}
