package com.example.recyclerviewexample.activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.recyclerviewexample.R;

public class RetrofitActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_retrofit);
    }
}
