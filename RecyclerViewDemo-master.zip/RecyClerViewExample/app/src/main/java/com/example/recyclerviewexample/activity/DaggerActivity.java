package com.example.recyclerviewexample.activity;

import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.recyclerviewexample.R;
import com.example.recyclerviewexample.dagger.Chef;
import com.example.recyclerviewexample.dagger.dash.DashFragment;
import com.example.recyclerviewexample.utils.ActivityUtils;

import javax.inject.Inject;

import dagger.android.support.DaggerAppCompatActivity;

public class DaggerActivity extends DaggerAppCompatActivity {

    @Inject
    DashFragment mDashFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dagger);

        DashFragment dashFragment = (DashFragment) getSupportFragmentManager().findFragmentById(R.id.content_fragment);
        if (dashFragment == null) {
            dashFragment = mDashFragment;
        }
        ActivityUtils.addFragmentToActivity(getSupportFragmentManager(),dashFragment,R.id.content_fragment);

        initView();
    }

    private void initView() {
        FloatingActionButton floatingActionButton = findViewById(R.id.fab);
        floatingActionButton.setOnClickListener(v -> {
        });
    }
}
