package com.example.recyclerviewexample.mvp.model.impl;

import com.example.recyclerviewexample.mvp.model.ILoginModel;

public class LoginModeImpl implements ILoginModel {

    @Override
    public void handleLogin() {

    }

    @Override
    public void handleLoginOut() {

    }
}
