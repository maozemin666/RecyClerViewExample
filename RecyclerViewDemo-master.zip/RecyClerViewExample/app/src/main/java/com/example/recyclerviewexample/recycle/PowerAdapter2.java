package com.example.recyclerviewexample.recycle;

public class PowerAdapter2 {
}
