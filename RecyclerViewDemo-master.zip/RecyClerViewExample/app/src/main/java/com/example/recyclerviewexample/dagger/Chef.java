package com.example.recyclerviewexample.dagger;

import java.util.Map;
import java.util.Set;

public class Chef implements Cooking {

    Menu menu;

    public Chef(Menu menu) {
        this.menu = menu;
    }

    @Override
    public String cook() {
        Map<String,Boolean> map = menu.getMenus();
        Set<String> key =  map.keySet();
        StringBuilder stringBuilder = new StringBuilder();
        for (String s : key) {
            Boolean value = map.get(s);
            if (value) {
                stringBuilder.append(s).append(",");
            }
        }
        return stringBuilder.toString();
    }
}
