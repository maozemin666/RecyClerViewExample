package com.example.recyclerviewexample.recyclerview.refresh.view;

import android.support.v7.widget.RecyclerView;

public class ViewDataObserver extends RecyclerView.AdapterDataObserver {

}
