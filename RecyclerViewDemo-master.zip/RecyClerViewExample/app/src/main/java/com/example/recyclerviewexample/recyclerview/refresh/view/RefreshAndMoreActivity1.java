package com.example.recyclerviewexample.recyclerview.refresh.view;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.view.View;

import com.example.recyclerviewexample.R;

public class RefreshAndMoreActivity1 extends AppCompatActivity {
    private YCRefreshView recyclerview;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_refresh_and_more1);
        initView();

    }

    private void initView() {
        recyclerview = findViewById(R.id.recyclerview);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        recyclerview.setLinearLayoutManager(linearLayoutManager);

    }
}
