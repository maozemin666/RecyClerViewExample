package com.example.recyclerviewexample.dagger;

public interface Cooking {
    String cook();
}
