package com.example.recyclerviewexample.mvp.model;

public interface ILoginModel {

    void handleLogin();

    void handleLoginOut();
}
