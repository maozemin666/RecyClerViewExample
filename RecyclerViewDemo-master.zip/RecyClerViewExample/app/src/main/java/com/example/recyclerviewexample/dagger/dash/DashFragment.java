package com.example.recyclerviewexample.dagger.dash;

import dagger.android.support.DaggerFragment;

public class DashFragment extends DaggerFragment {



}
